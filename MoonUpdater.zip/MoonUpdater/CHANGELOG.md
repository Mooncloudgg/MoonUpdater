# Liquid Updater

## [v14](https://github.com/LiquidTools/LiquidUpdater/tree/v14) (2024-10-11)
[Full Changelog](https://github.com/LiquidTools/LiquidUpdater/compare/v13...v14) [Previous Releases](https://github.com/LiquidTools/LiquidUpdater/releases)

- WeakAura update  
