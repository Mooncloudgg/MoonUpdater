local _, LUP = ...

local LDB = LibStub("LibDataBroker-1.1")
local LDBIcon = LibStub("LibDBIcon-1.0")
local eventFrame = CreateFrame("Frame")

eventFrame:RegisterEvent("ADDON_LOADED")

eventFrame:SetScript(
    "OnEvent",
    function(_, event, ...)
        if event == "ADDON_LOADED" then
            local addOnName = ...

            if addOnName == "MoonUpdater" then
                if not MoonUpdaterSaved then MoonUpdaterSaved = {} end
                if not MoonUpdaterSaved.minimap then MoonUpdaterSaved.minimap = {} end
                if not MoonUpdaterSaved.settings then MoonUpdaterSaved.settings = {} end
                if not MoonUpdaterSaved.settings.frames then MoonUpdaterSaved.settings.frames = {} end

                -- Minimap icon
                LUP.LDB = LDB:NewDataObject(
                    "Moon Updater",
                    {
                        type = "data source",
                        text = "Moon Updater",
                        icon = [[Interface\Addons\MoonUpdater\Media\Textures\minimap_logo.tga]],
                        OnClick = function() LUP.window:SetShown(not LUP.window:IsShown()) end
                    }
                )

                LDBIcon:Register("Moon Updater", LUP.LDB, MoonUpdaterSaved.minimap)

                LUP:InitializeWeakAurasImporter()
                LUP:InitializeInterface()
                LUP:InitializeAuraUpdater()
                LUP:InitializeAuraChecker()
            end
        end
    end
)

SLASH_MOONUPDATER1, SLASH_MOONUPDATER2, SLASH_MOONUPDATER3 = "/mu", "/moonupdate", "/moonupdater"
function SlashCmdList.MOONUPDATER()
    LUP.window:SetShown(not LUP.window:IsShown())
end